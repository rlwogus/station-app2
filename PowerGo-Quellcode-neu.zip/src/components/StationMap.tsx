import { useEffect, useRef } from 'react';
import type { Map as LeafletMap, LayerGroup } from 'leaflet';
import type { Station } from '@/lib/powergo-data';

type Props = { stations: Station[]; single?: boolean };

export function StationMap({ stations, single = false }: Props) {
  const container = useRef<HTMLDivElement>(null);
  const map = useRef<LeafletMap | null>(null);
  const markers = useRef<LayerGroup | null>(null);
  const leaflet = useRef<typeof import('leaflet') | null>(null);

  useEffect(() => {
    let cancelled = false;
    import('leaflet').then((L) => {
      if (cancelled || !container.current) return;
      leaflet.current = L;
      const instance = L.map(container.current, { scrollWheelZoom: false }).setView([52.373, 9.735], 13);
      L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap contributors</a>',
        maxZoom: 19,
      }).addTo(instance);
      map.current = instance;
      markers.current = L.layerGroup().addTo(instance);
      drawMarkers(L, instance, markers.current, stations, single);
      requestAnimationFrame(() => instance.invalidateSize());
    });
    return () => {
      cancelled = true;
      map.current?.remove();
      map.current = null;
      markers.current = null;
      leaflet.current = null;
    };
    // The map is created only once; marker updates are handled below.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (leaflet.current && map.current && markers.current) {
      drawMarkers(leaflet.current, map.current, markers.current, stations, single);
    }
  }, [stations, single]);

  return <div ref={container} className="station-map h-[340px] w-full overflow-hidden rounded-md border border-border bg-secondary sm:h-[420px]" role="region" aria-label={single ? `Karte von ${stations[0]?.name ?? 'Hannover'}` : 'Karte der PowerGo-Stationen in Hannover'} />;
}

function drawMarkers(L: typeof import('leaflet'), map: LeafletMap, layer: LayerGroup, stations: Station[], single: boolean) {
  layer.clearLayers();
  stations.forEach((station) => {
    const icon = L.divIcon({ className: `powergo-marker ${station.available ? '' : 'powergo-marker-empty'}`, html: '<span aria-hidden="true"></span>', iconSize: [32, 40], iconAnchor: [16, 40] });
    const marker = L.marker([station.lat, station.lng], { icon, title: `${station.name}: ${station.available} Powerbanks verfügbar` }).addTo(layer);
    const popup = document.createElement('div');
    const name = document.createElement('strong');
    name.textContent = station.name;
    const address = document.createElement('div');
    address.textContent = station.address;
    const count = document.createElement('div');
    count.textContent = `${station.available} von ${station.total} verfügbar`;
    const link = document.createElement('a');
    link.href = `/stationen/${encodeURIComponent(station.id)}`;
    link.textContent = 'Stationsdetails ansehen →';
    popup.append(name, address, count, link);
    marker.bindPopup(popup);
    marker.bindTooltip(station.name, { direction: 'top', offset: [0, -32] });
  });
  if (single && stations[0]) map.setView([stations[0].lat, stations[0].lng], 15);
  else if (stations.length > 1) map.fitBounds(L.latLngBounds(stations.map(s => [s.lat, s.lng] as [number, number])), { padding: [48, 48], maxZoom: 14 });
  else if (stations[0]) map.setView([stations[0].lat, stations[0].lng], 14);
  else map.setView([52.373, 9.735], 13);
}