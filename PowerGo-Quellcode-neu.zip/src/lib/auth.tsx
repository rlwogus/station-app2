import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import { Link, useNavigate } from '@tanstack/react-router';
import type { Session, User } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';

type AuthState = { user: User | null; session: Session | null; loading: boolean; displayName: string; signOut: () => Promise<void> };
const AuthContext = createContext<AuthState>({ user: null, session: null, loading: true, displayName: '', signOut: async () => {} });

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const { data } = supabase.auth.onAuthStateChange((_event, next) => {
      setSession(next);
      setLoading(false);
    });
    supabase.auth.getSession().then(({ data: s }) => {
      setSession(s.session);
      setLoading(false);
    });
    return () => data.subscription.unsubscribe();
  }, []);

  const user = session?.user ?? null;
  const meta = user?.user_metadata as { display_name?: string } | undefined;
  const displayName = meta?.display_name || user?.email?.split('@')[0] || '';
  const signOut = async () => { await supabase.auth.signOut(); };

  return <AuthContext.Provider value={{ user, session, loading, displayName, signOut }}>{children}</AuthContext.Provider>;
}

export const useAuth = () => useContext(AuthContext);

/** Zeigt den Inhalt nur für eingeloggte Nutzer, sonst Hinweis mit Link zum Login. */
export function RequireAuth({ children }: { children: ReactNode }) {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  useEffect(() => { if (!loading && !user) void navigate({ to: '/login' }); }, [loading, user, navigate]);
  if (loading) return <main className="page-wrap min-h-[60vh] py-16 text-muted-foreground">Lädt …</main>;
  if (!user) return <main className="page-wrap min-h-[60vh] py-16"><h1 className="heading-xl">Bitte anmelden</h1><p className="mt-4 text-muted-foreground">Für diese Seite brauchst du ein Konto.</p><Button asChild variant="brand" size="lg" className="mt-8"><Link to="/login">Zur Anmeldung</Link></Button></main>;
  return <>{children}</>;
}
