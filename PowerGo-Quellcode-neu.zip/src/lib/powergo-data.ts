import type { Tables } from '@/integrations/supabase/types';

export type Station = {
  id: string;
  ownerId: string | null;
  name: string;
  type: string;
  address: string;
  area: string;
  available: number;
  total: number;
  hours: string;
  landmark: string;
  email: string;
  lat: number;
  lng: number;
  imageUrl: string | null;
};

export const HANNOVER_CENTER = { lat: 52.3741, lng: 9.7387 };
export const STATION_TYPES = ['Café', 'Restaurant', 'Laden', 'Büro', 'Hotel', 'Sonstiges'];

export function toStation(row: Tables<'stations'>): Station {
  return {
    id: row.id,
    ownerId: row.owner_id,
    name: row.name,
    type: row.type,
    address: row.address,
    area: row.district,
    available: row.available,
    total: row.capacity,
    hours: row.opening_hours || 'Keine Angabe',
    landmark: row.location_hint || 'Keine Angabe',
    email: row.contact_email,
    lat: row.lat,
    lng: row.lng,
    imageUrl: row.image_url,
  };
}
