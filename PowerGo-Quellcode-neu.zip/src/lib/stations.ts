import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toStation, type Station } from '@/lib/powergo-data';

const BUCKET = 'station-images';

export function errorText(error: unknown): string {
  const msg = error instanceof Error ? error.message : typeof error === 'object' && error && 'message' in error ? String((error as { message: unknown }).message) : '';
  if (/Invalid login credentials/i.test(msg)) return 'E-Mail oder Passwort ist falsch.';
  if (/already registered|already been registered/i.test(msg)) return 'Diese E-Mail-Adresse ist bereits registriert.';
  if (/Password should be at least/i.test(msg)) return 'Das Passwort muss mindestens 6 Zeichen lang sein.';
  if (/Email not confirmed/i.test(msg)) return 'Bitte bestätige zuerst deine E-Mail-Adresse.';
  if (/row-level security|permission denied/i.test(msg)) return 'Dafür hast du keine Berechtigung.';
  if (/Failed to fetch|NetworkError/i.test(msg)) return 'Keine Verbindung zum Server. Bitte versuche es erneut.';
  return msg || 'Etwas ist schiefgelaufen. Bitte versuche es erneut.';
}

async function fetchStations(): Promise<Station[]> {
  const { data, error } = await supabase.from('stations').select('*').order('created_at', { ascending: true });
  if (error) throw error;
  return (data ?? []).map(toStation);
}

export const useStations = () => useQuery({ queryKey: ['stations'], queryFn: fetchStations });

export const useStation = (id: string) =>
  useQuery({
    queryKey: ['stations', id],
    enabled: Boolean(id),
    queryFn: async (): Promise<Station | null> => {
      const { data, error } = await supabase.from('stations').select('*').eq('id', id).maybeSingle();
      if (error) throw error;
      return data ? toStation(data) : null;
    },
  });

export type StationInput = {
  name: string;
  type: string;
  address: string;
  district: string;
  capacity: number;
  opening_hours: string;
  contact_email: string;
  location_hint: string;
};

export async function uploadStationImage(userId: string, file: File): Promise<string> {
  if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) throw new Error('Bitte wähle ein Bild (JPG, PNG oder WebP).');
  if (file.size > 5 * 1024 * 1024) throw new Error('Das Bild darf höchstens 5 MB groß sein.');
  const ext = file.type === 'image/png' ? 'png' : file.type === 'image/webp' ? 'webp' : 'jpg';
  const path = `${userId}/${crypto.randomUUID()}.${ext}`;
  const { error } = await supabase.storage.from(BUCKET).upload(path, file, { contentType: file.type });
  if (error) throw error;
  return supabase.storage.from(BUCKET).getPublicUrl(path).data.publicUrl;
}

async function removeImage(url: string | null) {
  if (!url) return;
  const marker = `/${BUCKET}/`;
  const i = url.indexOf(marker);
  if (i < 0) return;
  await supabase.storage.from(BUCKET).remove([decodeURIComponent(url.slice(i + marker.length))]);
}

export async function createStation(input: StationInput, imageUrl: string | null) {
  const { error } = await supabase.from('stations').insert({ ...input, available: input.capacity, image_url: imageUrl });
  if (error) throw error;
}

export async function updateStation(station: Station, input: StationInput, imageUrl: string | null) {
  const available = Math.min(station.available, input.capacity);
  const { error } = await supabase.from('stations').update({ ...input, available, image_url: imageUrl }).eq('id', station.id);
  if (error) throw error;
  if (imageUrl !== station.imageUrl) await removeImage(station.imageUrl).catch(() => undefined);
}

export async function deleteStation(station: Station) {
  const { error } = await supabase.from('stations').delete().eq('id', station.id);
  if (error) throw error;
  await removeImage(station.imageUrl).catch(() => undefined);
}

export type Rental = { id: string; stationId: string; stationName: string; startedAt: string; returnedAt: string | null };

export const useRentals = (userId: string | undefined) =>
  useQuery({
    queryKey: ['rentals', userId],
    enabled: Boolean(userId),
    queryFn: async (): Promise<Rental[]> => {
      const { data, error } = await supabase.from('rentals').select('id, station_id, started_at, returned_at, stations(name)').order('started_at', { ascending: false });
      if (error) throw error;
      return (data ?? []).map((r) => ({ id: r.id, stationId: r.station_id, stationName: r.stations?.name ?? 'Station', startedAt: r.started_at, returnedAt: r.returned_at }));
    },
  });

export async function borrowPowerbank(stationId: string) {
  const { error } = await supabase.rpc('borrow_powerbank', { p_station: stationId });
  if (error) throw error;
}

export async function returnPowerbank(rentalId: string, stationId: string) {
  const { error } = await supabase.rpc('return_powerbank', { p_rental: rentalId, p_station: stationId });
  if (error) throw error;
}
