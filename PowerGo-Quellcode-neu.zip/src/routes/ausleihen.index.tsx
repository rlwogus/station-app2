import { createFileRoute, Link } from '@tanstack/react-router';
import { ArrowRight, BatteryCharging, Clock3 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { PageHeading } from '@/components/PowerGo';
import { RequireAuth, useAuth } from '@/lib/auth';
import { errorText, useRentals } from '@/lib/stations';
import { pageHead } from '@/lib/seo';

export const Route = createFileRoute('/ausleihen/')({
  head: () => pageHead('Meine Ausleihen — PowerGo', 'Übersicht deiner aktuellen und vergangenen Powerbank-Ausleihen bei PowerGo.'),
  component: () => <RequireAuth><Rentals /></RequireAuth>,
});

const fmt = (iso: string) => new Date(iso).toLocaleString('de-DE', { dateStyle: 'medium', timeStyle: 'short' });

function Rentals() {
  const { user } = useAuth();
  const { data = [], isLoading, error } = useRentals(user?.id);
  const active = data.filter((r) => !r.returnedAt);
  const past = data.filter((r) => r.returnedAt);
  return <main className="page-wrap min-h-[75vh] py-12 md:py-16">
    <PageHeading eyebrow="Deine Übersicht" title="Meine Ausleihen" description="Hier siehst du deine laufenden und abgeschlossenen Ausleihen." />
    {error && <p role="alert" className="mb-6 rounded-md bg-destructive/10 p-4 text-sm text-destructive">{errorText(error)}</p>}
    {isLoading ? <p className="text-muted-foreground">Wird geladen …</p> : <div className="grid gap-10 lg:grid-cols-2">
      <section><h2 className="font-display text-2xl font-bold">Aktuelle Ausleihe</h2>
        {active.length ? <ul className="mt-5 space-y-3">{active.map((r) => <li key={r.id} className="station-card p-6"><p className="font-display text-xl font-bold">{r.stationName}</p><p className="mt-1 text-sm text-muted-foreground">Seit {fmt(r.startedAt)}</p><Button asChild variant="brand" size="lg" className="mt-5"><Link to="/rueckgabe">Jetzt zurückgeben <ArrowRight /></Link></Button></li>)}</ul>
          : <div className="mt-5 rounded-lg border border-dashed border-border bg-card p-8 text-center"><span className="mx-auto flex size-16 items-center justify-center rounded-full bg-brand-soft text-brand"><BatteryCharging className="size-8" /></span><h3 className="mt-5 font-display text-xl font-bold">Noch keine aktive Ausleihe</h3><p className="mx-auto mt-2 max-w-xs text-sm leading-6 text-muted-foreground">Sobald du eine Powerbank ausleihst, findest du sie hier.</p><Button asChild variant="brand" size="lg" className="mt-6"><Link to="/stationen">Station finden <ArrowRight /></Link></Button></div>}
      </section>
      <section><h2 className="font-display text-2xl font-bold">Vergangene Ausleihen</h2>
        {past.length ? <ul className="mt-5 space-y-3">{past.map((r) => <li key={r.id} className="station-card p-5"><p className="font-semibold">{r.stationName}</p><p className="mt-1 text-sm text-muted-foreground">{fmt(r.startedAt)} – {fmt(r.returnedAt ?? r.startedAt)}</p></li>)}</ul>
          : <div className="mt-5 rounded-lg border border-dashed border-border bg-card p-8 text-center"><span className="mx-auto flex size-16 items-center justify-center rounded-full bg-secondary text-muted-foreground"><Clock3 className="size-8" /></span><h3 className="mt-5 font-display text-xl font-bold">Noch kein Verlauf</h3><p className="mx-auto mt-2 max-w-xs text-sm leading-6 text-muted-foreground">Abgeschlossene Ausleihen erscheinen hier.</p></div>}
      </section>
    </div>}
  </main>;
}
