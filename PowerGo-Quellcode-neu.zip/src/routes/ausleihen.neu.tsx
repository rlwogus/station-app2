import { createFileRoute, Link, useNavigate } from '@tanstack/react-router';
import { useQueryClient } from '@tanstack/react-query';
import { ArrowRight, BatteryCharging, MapPin, ScanLine } from 'lucide-react';
import { useState } from 'react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { PageHeading } from '@/components/PowerGo';
import { RequireAuth } from '@/lib/auth';
import { borrowPowerbank, errorText, useStation } from '@/lib/stations';
import { pageHead } from '@/lib/seo';

export const Route = createFileRoute('/ausleihen/neu')({
  validateSearch: (search: Record<string, unknown>): { station?: string } => (typeof search['station'] === 'string' ? { station: search['station'] } : {}),
  head: () => pageHead('Powerbank ausleihen — PowerGo', 'Powerbank an einer PowerGo-Station ausleihen.'),
  component: () => <RequireAuth><Borrow /></RequireAuth>,
});

function Borrow() {
  const { station: stationId } = Route.useSearch();
  const { data: station, isLoading } = useStation(stationId ?? '');
  const [busy, setBusy] = useState(false);
  const navigate = useNavigate();
  const qc = useQueryClient();

  const start = async () => {
    if (!station) return;
    setBusy(true);
    try {
      await borrowPowerbank(station.id);
      await Promise.all([qc.invalidateQueries({ queryKey: ['stations'] }), qc.invalidateQueries({ queryKey: ['rentals'] })]);
      toast.success('Ausleihe gestartet. Viel Spaß!');
      void navigate({ to: '/ausleihen' });
    } catch (err) {
      toast.error(errorText(err));
    } finally {
      setBusy(false);
    }
  };

  const steps = [{ icon: MapPin, title: 'Station auswählen', text: 'Wähle die Station, an der du deine Powerbank abholen möchtest.' }, { icon: ScanLine, title: 'Powerbank entnehmen', text: 'Nimm eine Powerbank aus der Station mit.' }, { icon: BatteryCharging, title: 'Unterwegs aufladen', text: 'Lade dein Gerät auf und gib die Powerbank danach zurück.' }];
  return <main className="page-wrap min-h-[70vh] py-12 md:py-16">
    <PageHeading eyebrow="Ausleihe" title="Powerbank ausleihen" description="Prüfe deine Auswahl und starte die Ausleihe." />
    <div className="grid gap-10 lg:grid-cols-[1.3fr_1fr]">
      <div>{steps.map((item, i) => <div key={item.title} className="flex gap-5 border-b border-border py-6"><span className="flex size-11 shrink-0 items-center justify-center rounded-md bg-brand-soft text-brand"><item.icon className="size-5" /></span><div><p className="text-xs font-bold text-brand">SCHRITT 0{i + 1}</p><h2 className="mt-1 font-display text-lg font-bold">{item.title}</h2><p className="mt-2 text-sm leading-6 text-muted-foreground">{item.text}</p></div></div>)}</div>
      <aside className="self-start rounded-lg border border-border bg-card p-6">
        <p className="eyebrow">Deine Auswahl</p>
        {isLoading ? <p className="mt-3 text-muted-foreground">Wird geladen …</p> : !station ? <><p className="mt-3 text-muted-foreground">Keine Station ausgewählt.</p><Button asChild variant="brand" size="lg" className="mt-6 w-full"><Link to="/stationen">Station wählen</Link></Button></> : <>
          <h2 className="mt-3 font-display text-2xl font-bold">{station.name}</h2><p className="mt-2 text-sm text-muted-foreground">{station.address}</p>
          <div className="mt-6 flex items-center justify-between border-y border-border py-5 text-sm"><span>Powerbanks verfügbar</span><strong className="text-brand">{station.available} von {station.total}</strong></div>
          <Button disabled={busy || station.available < 1} onClick={() => void start()} variant="brand" size="lg" className="mt-6 w-full">{busy ? 'Bitte warten …' : 'Ausleihe starten'} <ArrowRight /></Button>
          <Button asChild variant="outline" size="lg" className="mt-3 w-full"><Link to="/stationen">Andere Station wählen</Link></Button></>}
      </aside>
    </div>
  </main>;
}
