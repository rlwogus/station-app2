import { createFileRoute, Link, useNavigate } from '@tanstack/react-router';
import { useEffect, useState, type FormEvent } from 'react';
import { BatteryCharging, LockKeyhole } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/lib/auth';
import { errorText } from '@/lib/stations';
import { pageHead } from '@/lib/seo';

export const Route = createFileRoute('/login')({
  head: () => pageHead('Anmelden oder registrieren — PowerGo', 'Melde dich bei PowerGo an oder erstelle ein Konto.'),
  component: Login,
});

function Login() {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const { user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => { if (user) void navigate({ to: '/stationen' }); }, [user, navigate]);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      if (mode === 'login') {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        toast.success('Willkommen zurück!');
      } else {
        const { data, error } = await supabase.auth.signUp({ email, password, options: { data: { display_name: name.trim() } } });
        if (error) throw error;
        if (data.session) toast.success('Konto erstellt. Willkommen bei PowerGo!');
        else { toast.success('Konto erstellt. Bitte bestätige deine E-Mail-Adresse und melde dich dann an.'); setMode('login'); }
      }
    } catch (err) {
      toast.error(errorText(err));
    } finally {
      setBusy(false);
    }
  };

  return <main className="page-wrap grid min-h-[75vh] gap-12 py-12 md:grid-cols-2 md:items-center md:py-20">
    <div className="max-w-lg">
      <span className="icon-box !size-14"><BatteryCharging className="size-7" /></span>
      <p className="eyebrow mt-8">Dein PowerGo-Konto</p>
      <h1 className="heading-xl mt-3">Immer bereit, wenn du Energie brauchst.</h1>
      <p className="mt-6 text-lg leading-8 text-muted-foreground">Mit deinem Konto kannst du Stationen eintragen, bearbeiten und Powerbanks ausleihen.</p>
      <div className="mt-8 flex items-center gap-3 border-t border-border pt-6 text-sm text-muted-foreground"><LockKeyhole className="size-5 text-brand" /> Sicher angemeldet mit Supabase Auth</div>
    </div>
    <div className="mx-auto w-full max-w-md">
      <div className="rounded-lg border border-border bg-card p-6 shadow-sm sm:p-8">
        <div className="grid grid-cols-2 gap-1 rounded-md bg-secondary p-1">
          <Button type="button" variant={mode === 'login' ? 'default' : 'ghost'} onClick={() => setMode('login')}>Anmelden</Button>
          <Button type="button" variant={mode === 'register' ? 'default' : 'ghost'} onClick={() => setMode('register')}>Registrieren</Button>
        </div>
        <h2 className="mt-8 font-display text-2xl font-bold">{mode === 'login' ? 'Willkommen zurück' : 'Konto erstellen'}</h2>
        <p className="mt-2 text-sm text-muted-foreground">{mode === 'login' ? 'Melde dich bei PowerGo an.' : 'Starte mit deinem PowerGo-Konto.'}</p>
        <form className="mt-7 space-y-5" onSubmit={submit}>
          {mode === 'register' && <label className="block text-sm font-semibold">Name<input required className="field mt-2" placeholder="Dein Name" autoComplete="name" value={name} onChange={(e) => setName(e.target.value)} /></label>}
          <label className="block text-sm font-semibold">E-Mail-Adresse<input required className="field mt-2" type="email" placeholder="name@beispiel.de" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} /></label>
          <label className="block text-sm font-semibold">Passwort<input required minLength={6} className="field mt-2" type="password" placeholder="Mindestens 6 Zeichen" autoComplete={mode === 'login' ? 'current-password' : 'new-password'} value={password} onChange={(e) => setPassword(e.target.value)} /></label>
          <Button type="submit" disabled={busy} variant="brand" size="lg" className="w-full">{busy ? 'Bitte warten …' : mode === 'login' ? 'Anmelden' : 'Konto erstellen'}</Button>
        </form>
      </div>
      <p className="mt-5 text-center text-sm text-muted-foreground">Erst mal umsehen? <Link to="/stationen" className="font-bold text-brand hover:underline">Stationen entdecken</Link></p>
    </div>
  </main>;
}
