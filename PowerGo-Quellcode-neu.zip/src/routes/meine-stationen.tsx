import { createFileRoute, Link } from '@tanstack/react-router';
import { useQueryClient } from '@tanstack/react-query';
import { Pencil, Plus, Trash2 } from 'lucide-react';
import { useState } from 'react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { PageHeading, StationCard } from '@/components/PowerGo';
import { RequireAuth, useAuth } from '@/lib/auth';
import type { Station } from '@/lib/powergo-data';
import { deleteStation, errorText, useStations } from '@/lib/stations';
import { pageHead } from '@/lib/seo';

export const Route = createFileRoute('/meine-stationen')({
  head: () => pageHead('Meine Stationen — PowerGo', 'Verwalte deine eigenen PowerGo-Stationen.'),
  component: () => <RequireAuth><MyStations /></RequireAuth>,
});

function MyStations() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const { data: stations = [], isLoading, error } = useStations();
  const [toDelete, setToDelete] = useState<Station | null>(null);
  const mine = stations.filter((s) => s.ownerId === user?.id);

  const confirmDelete = async () => {
    if (!toDelete) return;
    try {
      await deleteStation(toDelete);
      await qc.invalidateQueries({ queryKey: ['stations'] });
      toast.success('Station gelöscht.');
    } catch (err) {
      toast.error(errorText(err));
    } finally {
      setToDelete(null);
    }
  };

  return <main className="page-wrap min-h-[70vh] py-12 md:py-16">
    <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
      <PageHeading eyebrow="Deine Übersicht" title="Meine Stationen" description="Hier siehst du alle Stationen, die du eingetragen hast." />
      <Button asChild variant="brand" size="lg" className="mb-9"><Link to="/stationen/anbieten"><Plus /> Neue Station</Link></Button>
    </div>
    {error && <p role="alert" className="rounded-md bg-destructive/10 p-4 text-sm text-destructive">{errorText(error)}</p>}
    {isLoading ? <p className="text-muted-foreground">Wird geladen …</p> : mine.length ? <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">{mine.map((s) => <div key={s.id} className="flex flex-col gap-3"><div className="flex-1"><StationCard station={s} /></div><div className="grid grid-cols-2 gap-3"><Button asChild variant="outline"><Link to="/stationen/anbieten" search={{ edit: s.id }}><Pencil /> Bearbeiten</Link></Button><Button variant="outline" className="text-destructive hover:text-destructive" onClick={() => setToDelete(s)}><Trash2 /> Löschen</Button></div></div>)}</div> : <div className="rounded-lg border border-dashed border-border bg-card p-10 text-center"><h2 className="font-display text-xl font-bold">Noch keine eigenen Stationen</h2><p className="mt-2 text-sm text-muted-foreground">Trage dein erstes Geschäft als Station ein.</p><Button asChild variant="brand" size="lg" className="mt-6"><Link to="/stationen/anbieten">Station eintragen</Link></Button></div>}
    <AlertDialog open={Boolean(toDelete)} onOpenChange={(o) => { if (!o) setToDelete(null); }}>
      <AlertDialogContent>
        <AlertDialogHeader><AlertDialogTitle>Wirklich löschen?</AlertDialogTitle><AlertDialogDescription>Die Station „{toDelete?.name}“ wird endgültig gelöscht. Das kann nicht rückgängig gemacht werden.</AlertDialogDescription></AlertDialogHeader>
        <AlertDialogFooter><AlertDialogCancel>Abbrechen</AlertDialogCancel><AlertDialogAction onClick={() => void confirmDelete()}>Löschen</AlertDialogAction></AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  </main>;
}
