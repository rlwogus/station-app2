import { createFileRoute, Link } from '@tanstack/react-router';
import { ArrowRight, BatteryCharging, Store, UserRound } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { PageHeading } from '@/components/PowerGo';
import { useAuth } from '@/lib/auth';
import { pageHead } from '@/lib/seo';

export const Route = createFileRoute('/profil')({
  head: () => pageHead('Mein Profil — PowerGo', 'Dein PowerGo-Profil und deine persönlichen Ausleihen.'),
  component: Profile,
});

function Profile() {
  const { user, loading, displayName, signOut } = useAuth();
  return <main className="page-wrap min-h-[70vh] py-12 md:py-16">
    <PageHeading eyebrow="Dein Konto" title="Mein Profil" description={user ? 'Deine Kontodaten und Schnellzugriffe.' : 'Melde dich an, um dein Profil zu sehen.'} />
    <div className="grid gap-6 md:grid-cols-[1.2fr_1fr]">
      <section className="station-card p-7">
        <div className="flex items-center gap-4">
          <span className="flex size-16 shrink-0 items-center justify-center rounded-full bg-brand-soft text-brand"><UserRound className="size-8" /></span>
          <div className="min-w-0"><h2 className="font-display text-xl font-bold">{loading ? 'Lädt …' : user ? displayName : 'Noch nicht angemeldet'}</h2><p className="mt-1 break-all text-sm text-muted-foreground">{user ? user.email : 'Melde dich an, um dein Profil zu sehen.'}</p></div>
        </div>
        <div className="mt-7 border-t border-border pt-6">
          {user ? <Button size="lg" variant="outline" onClick={() => void signOut()}>Abmelden</Button> : <Button asChild variant="brand" size="lg"><Link to="/login">Zur Anmeldung <ArrowRight /></Link></Button>}
        </div>
      </section>
      <div className="grid gap-6">
        <section className="station-card p-7"><span className="icon-box"><Store className="size-5" /></span><h2 className="mt-5 font-display text-xl font-bold">Meine Stationen</h2><p className="mt-2 text-sm leading-6 text-muted-foreground">Trage Stationen ein, ändere sie oder lösche sie wieder.</p><Button asChild variant="outline" size="lg" className="mt-6"><Link to="/meine-stationen">Stationen verwalten <ArrowRight /></Link></Button></section>
        <section className="station-card p-7"><span className="icon-box"><BatteryCharging className="size-5" /></span><h2 className="mt-5 font-display text-xl font-bold">Deine Ausleihen</h2><p className="mt-2 text-sm leading-6 text-muted-foreground">Behalte aktuelle und vergangene Ausleihen im Blick.</p><Button asChild variant="outline" size="lg" className="mt-6"><Link to="/ausleihen">Ausleihen ansehen <ArrowRight /></Link></Button></section>
      </div>
    </div>
  </main>;
}
