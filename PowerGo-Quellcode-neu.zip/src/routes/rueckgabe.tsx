import { createFileRoute, Link, useNavigate } from '@tanstack/react-router';
import { useQueryClient } from '@tanstack/react-query';
import { ArrowRight, BatteryCharging, Check, MapPin } from 'lucide-react';
import { useState } from 'react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { PageHeading } from '@/components/PowerGo';
import { RequireAuth, useAuth } from '@/lib/auth';
import { errorText, returnPowerbank, useRentals } from '@/lib/stations';
import { pageHead } from '@/lib/seo';

export const Route = createFileRoute('/rueckgabe')({
  head: () => pageHead('Powerbank zurückgeben — PowerGo', 'So funktioniert die Rückgabe deiner PowerGo-Powerbank.'),
  component: () => <RequireAuth><ReturnPage /></RequireAuth>,
});

function ReturnPage() {
  const { user } = useAuth();
  const { data = [], isLoading } = useRentals(user?.id);
  const active = data.find((r) => !r.returnedAt);
  const [busy, setBusy] = useState(false);
  const navigate = useNavigate();
  const qc = useQueryClient();

  const giveBack = async () => {
    if (!active) return;
    setBusy(true);
    try {
      await returnPowerbank(active.id, active.stationId);
      await Promise.all([qc.invalidateQueries({ queryKey: ['stations'] }), qc.invalidateQueries({ queryKey: ['rentals'] })]);
      toast.success('Powerbank zurückgegeben. Danke!');
      void navigate({ to: '/ausleihen' });
    } catch (err) {
      toast.error(errorText(err));
    } finally {
      setBusy(false);
    }
  };

  const steps = [{ icon: MapPin, title: 'Station aufsuchen', text: 'Suche eine Station, an der du die Powerbank zurückgeben kannst.' }, { icon: BatteryCharging, title: 'Powerbank einstecken', text: 'Stecke die Powerbank in einen freien Platz der Station.' }, { icon: Check, title: 'Bestätigung erhalten', text: 'Nach der Rückgabe erscheint die Ausleihe in deinem Verlauf.' }];
  return <main className="page-wrap min-h-[70vh] py-12 md:py-16">
    <PageHeading eyebrow="Rückgabe" title="Powerbank zurückgeben" description="Gib deine Powerbank nach der Nutzung an einer Station zurück." />
    <div className="grid gap-10 lg:grid-cols-[1.2fr_1fr]">
      <div>{steps.map((step, i) => <div key={step.title} className="flex gap-5 border-b border-border py-6"><span className="flex size-11 shrink-0 items-center justify-center rounded-md bg-brand-soft text-brand"><step.icon className="size-5" /></span><div><p className="text-xs font-bold text-brand">SCHRITT 0{i + 1}</p><h2 className="mt-1 font-display text-lg font-bold">{step.title}</h2><p className="mt-2 text-sm leading-6 text-muted-foreground">{step.text}</p></div></div>)}<Button asChild variant="outline" size="lg" className="mt-8"><Link to="/stationen">Stationen ansehen <ArrowRight /></Link></Button></div>
      <aside className="self-start rounded-lg border border-border bg-card p-7 text-center">
        <span className="mx-auto flex size-16 items-center justify-center rounded-full bg-secondary text-muted-foreground"><BatteryCharging className="size-8" /></span>
        {isLoading ? <p className="mt-5 text-muted-foreground">Wird geladen …</p> : active ? <><h2 className="mt-5 font-display text-xl font-bold">Aktive Ausleihe</h2><p className="mt-2 text-sm leading-6 text-muted-foreground">Powerbank von „{active.stationName}“ ausgeliehen.</p><Button disabled={busy} onClick={() => void giveBack()} variant="brand" size="lg" className="mt-6 w-full">{busy ? 'Bitte warten …' : 'Jetzt zurückgeben'}</Button></> : <><h2 className="mt-5 font-display text-xl font-bold">Keine aktive Ausleihe</h2><p className="mt-2 text-sm leading-6 text-muted-foreground">Wenn du eine Powerbank ausgeliehen hast, kannst du sie hier zurückgeben.</p><Button asChild variant="brand" size="lg" className="mt-6 w-full"><Link to="/ausleihen">Meine Ausleihen</Link></Button></>}
      </aside>
    </div>
  </main>;
}
