import { createFileRoute, Link } from '@tanstack/react-router';
import { ArrowLeft, ArrowRight, BatteryCharging, Clock3, MapPin, Pencil } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { StatLine } from '@/components/PowerGo';
import { StationMap } from '@/components/StationMap';
import { useAuth } from '@/lib/auth';
import { useStation } from '@/lib/stations';
import { pageHead } from '@/lib/seo';

export const Route = createFileRoute('/stationen/$stationId')({
  head: () => pageHead('Station — PowerGo', 'PowerGo-Station: Verfügbarkeit, Adresse und Öffnungszeiten ansehen.'),
  component: StationDetail,
});

function StationDetail() {
  const { stationId } = Route.useParams();
  const { user } = useAuth();
  const { data: station, isLoading } = useStation(stationId);

  if (isLoading) return <main className="page-wrap min-h-[60vh] py-16 text-muted-foreground">Station wird geladen …</main>;
  if (!station) return <main className="page-wrap min-h-[60vh] py-16"><h1 className="heading-xl">Station nicht gefunden</h1><Button asChild className="mt-8"><Link to="/stationen">Alle Stationen</Link></Button></main>;

  const isOwner = Boolean(user && station.ownerId === user.id);
  return <main className="page-wrap min-h-[70vh] py-12 md:py-16">
    <Link to="/stationen" className="inline-flex items-center gap-2 text-sm font-bold text-muted-foreground hover:text-brand"><ArrowLeft className="size-4" /> Alle Stationen</Link>
    <div className="mt-8 grid gap-10 lg:grid-cols-[1.25fr_1fr]">
      <div>
        <p className="eyebrow">Station · {station.area || station.type}</p>
        <h1 className="heading-xl mt-3 break-words">{station.name}</h1>
        <p className="mt-4 flex items-center gap-2 text-muted-foreground"><MapPin className="size-5 shrink-0 text-brand" /> {station.address}</p>
        {station.imageUrl && <img src={station.imageUrl} alt={`Foto von ${station.name}`} className="mt-8 max-h-80 w-full rounded-md border border-border object-cover" />}
        <div className="mt-8"><StationMap stations={[station]} single /><p className="mt-2 text-xs text-muted-foreground">Karte: © OpenStreetMap</p></div>
      </div>
      <div>
        <div className="border-b border-border pb-6">
          <div className="flex items-center justify-between gap-4"><div><p className="text-sm text-muted-foreground">Verfügbarkeit</p><p className="mt-1 font-display text-5xl font-bold text-brand">{station.available}<span className="ml-2 text-xl text-muted-foreground">/ {station.total}</span></p></div><span className="icon-box !size-14"><BatteryCharging className="size-7" /></span></div>
          <div className="mt-5 h-2 overflow-hidden rounded-full bg-secondary"><div className="h-full rounded-full bg-brand" style={{ width: `${(station.available / station.total) * 100}%` }} /></div>
        </div>
        <div className="divide-y divide-border"><StatLine icon={Clock3} label="Öffnungszeiten" value={station.hours} /><StatLine icon={MapPin} label="Wo du die Station findest" value={station.landmark} /></div>
        {station.available ? <Button asChild variant="brand" size="lg" className="mt-8 w-full"><Link to="/ausleihen/neu" search={{ station: station.id }}>Powerbank ausleihen <ArrowRight /></Link></Button> : <Button disabled variant="brand" size="lg" className="mt-8 w-full">Derzeit nicht verfügbar</Button>}
        {isOwner && <Button asChild variant="outline" size="lg" className="mt-3 w-full"><Link to="/stationen/anbieten" search={{ edit: station.id }}><Pencil /> Station bearbeiten</Link></Button>}
      </div>
    </div>
  </main>;
}
