import { createFileRoute, Link, useNavigate } from '@tanstack/react-router';
import { useQueryClient } from '@tanstack/react-query';
import { ArrowLeft, ImagePlus, Store } from 'lucide-react';
import { useEffect, useState, type FormEvent, type ReactNode } from 'react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { PageHeading } from '@/components/PowerGo';
import { RequireAuth, useAuth } from '@/lib/auth';
import { STATION_TYPES, type Station } from '@/lib/powergo-data';
import { createStation, errorText, updateStation, uploadStationImage, useStation, type StationInput } from '@/lib/stations';
import { pageHead } from '@/lib/seo';

export const Route = createFileRoute('/stationen/anbieten')({
  validateSearch: (search: Record<string, unknown>): { edit?: string } => (typeof search['edit'] === 'string' ? { edit: search['edit'] } : {}),
  head: () => pageHead('Ladestation anbieten — PowerGo', 'Registriere dein Geschäft und biete eine PowerGo-Ladestation für Powerbanks an.'),
  component: () => <RequireAuth><AddStation /></RequireAuth>,
});

type Form = { business: string; type: string; address: string; area: string; hours: string; slots: string; landmark: string; email: string };
const empty: Form = { business: '', type: 'Café', address: '', area: '', hours: '', slots: '6', landmark: '', email: '' };
const fromStation = (s: Station): Form => ({ business: s.name, type: s.type, address: s.address, area: s.area, hours: s.hours === 'Keine Angabe' ? '' : s.hours, slots: String(s.total), landmark: s.landmark === 'Keine Angabe' ? '' : s.landmark, email: s.email });

function Field({ label, children }: { label: string; children: ReactNode }) {
  return <label className="block"><span className="mb-2 block text-sm font-semibold">{label}</span>{children}</label>;
}

function AddStation() {
  const { edit } = Route.useSearch();
  const { user } = useAuth();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const { data: existing, isLoading } = useStation(edit ?? '');
  const [form, setForm] = useState<Form>(empty);
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const editing = Boolean(edit);

  useEffect(() => { if (existing) { setForm(fromStation(existing)); setPreview(existing.imageUrl); } }, [existing]);
  useEffect(() => () => { if (preview?.startsWith('blob:')) URL.revokeObjectURL(preview); }, [preview]);

  const set = (k: keyof Form) => (e: { target: { value: string } }) => setForm({ ...form, [k]: e.target.value });
  const pick = (f: File | null) => {
    if (!f) return;
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(f.type)) return void toast.error('Bitte wähle ein Bild (JPG, PNG oder WebP).');
    if (f.size > 5 * 1024 * 1024) return void toast.error('Das Bild darf höchstens 5 MB groß sein.');
    setFile(f);
    setPreview(URL.createObjectURL(f));
  };

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setBusy(true);
    try {
      const input: StationInput = { name: form.business.trim(), type: form.type, address: form.address.trim(), district: form.area.trim(), capacity: Number(form.slots), opening_hours: form.hours.trim(), contact_email: form.email.trim(), location_hint: form.landmark.trim() };
      const imageUrl = file ? await uploadStationImage(user.id, file) : (existing?.imageUrl ?? null);
      if (existing) await updateStation(existing, input, imageUrl);
      else await createStation(input, imageUrl);
      await qc.invalidateQueries({ queryKey: ['stations'] });
      toast.success(existing ? 'Station gespeichert.' : 'Station eingetragen.');
      void navigate({ to: '/meine-stationen' });
    } catch (err) {
      toast.error(errorText(err));
    } finally {
      setBusy(false);
    }
  };

  if (editing && isLoading) return <main className="page-wrap min-h-[60vh] py-16 text-muted-foreground">Station wird geladen …</main>;
  if (editing && (!existing || existing.ownerId !== user?.id)) return <main className="page-wrap min-h-[60vh] py-16"><h1 className="heading-xl">Station nicht gefunden</h1><p className="mt-4 text-muted-foreground">Du kannst nur deine eigenen Stationen bearbeiten.</p><Button asChild className="mt-8"><Link to="/meine-stationen">Meine Stationen</Link></Button></main>;

  return <main className="page-wrap min-h-[70vh] py-12 md:py-16">
    <Link to="/meine-stationen" className="inline-flex items-center gap-2 text-sm font-bold text-muted-foreground hover:text-brand"><ArrowLeft className="size-4" /> Meine Stationen</Link>
    <div className="mt-8 grid gap-10 lg:grid-cols-[1fr_1.4fr]">
      <div><PageHeading eyebrow="Für Geschäfte" title={editing ? 'Station bearbeiten' : 'Ladestation anbieten'} description="Du hast ein Café, einen Laden oder ein Büro? Biete deinen Kundinnen und Kunden Powerbanks zum Ausleihen an." /><div className="flex items-start gap-3 rounded-lg bg-brand-soft p-5"><Store className="mt-0.5 size-6 shrink-0 text-brand" /><p className="text-sm">Trage dein Geschäft ein. Die Station erscheint danach sofort für alle in der Stationsliste.</p></div></div>
      <form onSubmit={submit} className="rounded-lg border border-border bg-card p-6 md:p-8">
        <div className="grid gap-5 sm:grid-cols-2">
          <Field label="Name des Geschäfts"><input required className="field" value={form.business} onChange={set('business')} placeholder="z. B. Café Sonne" /></Field>
          <Field label="Art"><select className="field" value={form.type} onChange={set('type')}>{STATION_TYPES.map((t) => <option key={t}>{t}</option>)}</select></Field>
          <div className="sm:col-span-2"><Field label="Adresse"><input required className="field" value={form.address} onChange={set('address')} placeholder="Straße, PLZ, Hannover" /></Field></div>
          <Field label="Stadtteil"><input className="field" value={form.area} onChange={set('area')} placeholder="z. B. Linden" /></Field>
          <Field label="Anzahl Ladeplätze"><input required type="number" min={1} max={50} className="field" value={form.slots} onChange={set('slots')} /></Field>
          <Field label="Öffnungszeiten"><input required className="field" value={form.hours} onChange={set('hours')} placeholder="z. B. Mo–Sa 08:00–20:00" /></Field>
          <Field label="Kontakt-E-Mail"><input required type="email" className="field" value={form.email} onChange={set('email')} placeholder="name@beispiel.de" /></Field>
          <div className="sm:col-span-2"><Field label="Wo steht die Station? (optional)"><input className="field" value={form.landmark} onChange={set('landmark')} placeholder="z. B. Neben der Kasse" /></Field></div>
          <div className="sm:col-span-2">
            <span className="mb-2 block text-sm font-semibold">Foto (optional, JPG/PNG/WebP, max. 5 MB)</span>
            <label className="flex cursor-pointer flex-col items-center justify-center gap-2 rounded-md border border-dashed border-border bg-secondary/40 p-5 text-sm text-muted-foreground hover:border-brand">
              {preview ? <img src={preview} alt="Vorschau" className="max-h-48 rounded-md object-cover" /> : <><ImagePlus className="size-6 text-brand" />Bild auswählen</>}
              <input type="file" accept="image/jpeg,image/png,image/webp" className="sr-only" onChange={(e) => pick(e.target.files?.[0] ?? null)} />
            </label>
          </div>
        </div>
        <Button type="submit" disabled={busy} variant="brand" size="lg" className="mt-8 w-full">{busy ? 'Wird gespeichert …' : editing ? 'Änderungen speichern' : 'Station eintragen'}</Button>
      </form>
    </div>
  </main>;
}
