import { createFileRoute, Link } from '@tanstack/react-router';
import { Search, MapPin, Store } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useMemo, useState } from 'react';
import { PageHeading, StationCard } from '@/components/PowerGo';
import { StationMap } from '@/components/StationMap';
import { useStations, errorText } from '@/lib/stations';
import { pageHead } from '@/lib/seo';

export const Route = createFileRoute('/stationen/')({
  head: () => pageHead('Stationen finden — PowerGo', 'Finde PowerGo-Stationen und prüfe die Verfügbarkeit von Powerbanks.'),
  component: Stations,
});

function Stations() {
  const [search, setSearch] = useState('');
  const [availableOnly, setAvailableOnly] = useState(false);
  const { data: stations = [], isLoading, error } = useStations();
  const filtered = useMemo(() => stations.filter((s) => `${s.name} ${s.area} ${s.address}`.toLocaleLowerCase('de').includes(search.toLocaleLowerCase('de')) && (!availableOnly || s.available > 0)), [stations, search, availableOnly]);

  return <main className="page-wrap min-h-[70vh] py-12 md:py-16">
    <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
      <PageHeading eyebrow="Standorte entdecken" title="Finde deine Station" description="Sieh nach, wo Powerbanks verfügbar sind." />
      <Button asChild variant="outline" size="lg" className="mb-9"><Link to="/stationen/anbieten"><Store /> Eigene Station anbieten</Link></Button>
    </div>
    <div className="mt-2 flex flex-col gap-4 sm:flex-row sm:items-center">
      <label className="relative block flex-1"><Search className="absolute left-4 top-1/2 size-5 -translate-y-1/2 text-muted-foreground" /><span className="sr-only">Station suchen</span><input className="field pl-12" placeholder="Station oder Stadtteil suchen" value={search} onChange={(e) => setSearch(e.target.value)} /></label>
      <label className="flex min-h-12 cursor-pointer items-center gap-3 whitespace-nowrap rounded-md border border-border bg-card px-4 text-sm font-semibold"><input type="checkbox" checked={availableOnly} onChange={(e) => setAvailableOnly(e.target.checked)} className="size-4 accent-brand" /> Nur verfügbare</label>
    </div>
    <div className="mt-5 flex items-center gap-2 text-sm text-muted-foreground"><MapPin className="size-4" /> Hannover · {filtered.length} {filtered.length === 1 ? 'Station' : 'Stationen'}</div>
    {error && <p role="alert" className="mt-6 rounded-md bg-destructive/10 p-4 text-sm text-destructive">Stationen konnten nicht geladen werden: {errorText(error)}</p>}
    <section className="mt-6" aria-label="Kartenübersicht"><StationMap stations={filtered} /><p className="mt-2 text-xs text-muted-foreground">Karte: © OpenStreetMap</p></section>
    {isLoading ? <p className="mt-8 text-muted-foreground">Stationen werden geladen …</p> : filtered.length ? <div className="mt-6 grid gap-5 md:grid-cols-2 lg:grid-cols-3">{filtered.map((s) => <StationCard key={s.id} station={s} />)}</div> : <div className="mt-8 border-t border-border py-14 text-center"><p className="font-display text-xl font-semibold">Keine Station gefunden</p><p className="mt-2 text-muted-foreground">Versuche einen anderen Suchbegriff.</p></div>}
  </main>;
}
