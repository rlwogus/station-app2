-- PowerGo: komplettes Setup für ein eigenes Supabase-Projekt
-- Im Supabase Dashboard: SQL Editor -> New query -> alles einfügen -> Run

-- 1) profiles ---------------------------------------------------------
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.profiles enable row level security;
drop policy if exists "profiles_read_own" on public.profiles;
drop policy if exists "profiles_insert_own" on public.profiles;
drop policy if exists "profiles_update_own" on public.profiles;
create policy "profiles_read_own" on public.profiles for select to authenticated using (auth.uid() = id);
create policy "profiles_insert_own" on public.profiles for insert to authenticated with check (auth.uid() = id);
create policy "profiles_update_own" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

-- Profil automatisch beim Registrieren anlegen (Name kommt aus den Metadaten)
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'display_name', ''))
  on conflict (id) do nothing;
  return new;
end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- 2) stations ---------------------------------------------------------
create table if not exists public.stations (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid references auth.users(id) on delete cascade default auth.uid(),
  name text not null,
  type text not null default 'Café',
  address text not null,
  district text not null default '',
  capacity int not null check (capacity between 1 and 50),
  available int not null check (available >= 0),
  opening_hours text not null default '',
  contact_email text not null default '',
  location_hint text not null default '',
  lat double precision not null default 52.3741,
  lng double precision not null default 9.7387,
  image_url text,
  created_at timestamptz not null default now(),
  constraint available_le_capacity check (available <= capacity)
);
alter table public.stations enable row level security;
drop policy if exists "stations_read_all" on public.stations;
drop policy if exists "stations_insert_own" on public.stations;
drop policy if exists "stations_update_own" on public.stations;
drop policy if exists "stations_delete_own" on public.stations;
create policy "stations_read_all" on public.stations for select to anon, authenticated using (true);
create policy "stations_insert_own" on public.stations for insert to authenticated with check (owner_id = auth.uid());
create policy "stations_update_own" on public.stations for update to authenticated using (owner_id = auth.uid()) with check (owner_id = auth.uid());
create policy "stations_delete_own" on public.stations for delete to authenticated using (owner_id = auth.uid());

-- 3) Beispielstationen (ohne Besitzer) -----------------------------------
insert into public.stations (name, type, address, district, capacity, available, opening_hours, location_hint, lat, lng)
select * from (values
  ('Kröpcke','Sonstiges','Kröpcke, 30159 Hannover','Mitte',12,8,'Täglich 06:00–23:00','Am Kröpcke',52.3741,9.7387),
  ('Hauptbahnhof','Sonstiges','Ernst-August-Platz, 30159 Hannover','Mitte',10,5,'Täglich 07:00–22:00','Am Ernst-August-Platz',52.3765,9.7414),
  ('Maschsee Nordufer','Sonstiges','Arthur-Menge-Ufer, 30169 Hannover','Südstadt',8,3,'Täglich 08:00–22:00','Am Nordufer',52.3632,9.7395),
  ('Küchengarten','Sonstiges','Küchengarten, 30449 Hannover','Linden',10,0,'Rund um die Uhr','Am Küchengarten',52.3712,9.7159)
) as v(name,type,address,district,capacity,available,opening_hours,location_hint,lat,lng)
where not exists (select 1 from public.stations where owner_id is null);

-- 4) Storage: Bucket für Stationsbilder ---------------------------------
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('station-images','station-images', true, 5242880, array['image/jpeg','image/png','image/webp'])
on conflict (id) do update set public = true, file_size_limit = 5242880,
  allowed_mime_types = array['image/jpeg','image/png','image/webp'];

drop policy if exists "station_images_read" on storage.objects;
drop policy if exists "station_images_insert_own" on storage.objects;
drop policy if exists "station_images_update_own" on storage.objects;
drop policy if exists "station_images_delete_own" on storage.objects;
create policy "station_images_read" on storage.objects for select to anon, authenticated
  using (bucket_id = 'station-images');
create policy "station_images_insert_own" on storage.objects for insert to authenticated
  with check (bucket_id = 'station-images' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "station_images_update_own" on storage.objects for update to authenticated
  using (bucket_id = 'station-images' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "station_images_delete_own" on storage.objects for delete to authenticated
  using (bucket_id = 'station-images' and (storage.foldername(name))[1] = auth.uid()::text);

-- 5) Rentals (Ausleihe/Rückgabe) ------------------------------------------
create table if not exists public.rentals (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade default auth.uid(),
  station_id uuid not null references public.stations(id) on delete cascade,
  started_at timestamptz not null default now(),
  returned_at timestamptz
);
alter table public.rentals enable row level security;
drop policy if exists "rentals_read_own" on public.rentals;
create policy "rentals_read_own" on public.rentals for select to authenticated using (user_id = auth.uid());
-- Schreiben nur über die Funktionen unten (kein direktes insert/update)

create or replace function public.borrow_powerbank(p_station uuid) returns uuid
language plpgsql security definer set search_path = public as $$
declare rid uuid;
begin
  if auth.uid() is null then raise exception 'Nicht angemeldet'; end if;
  if exists (select 1 from rentals where user_id = auth.uid() and returned_at is null) then
    raise exception 'Du hast bereits eine aktive Ausleihe';
  end if;
  update stations set available = available - 1 where id = p_station and available > 0;
  if not found then raise exception 'Keine Powerbank verfügbar'; end if;
  insert into rentals (user_id, station_id) values (auth.uid(), p_station) returning id into rid;
  return rid;
end; $$;

create or replace function public.return_powerbank(p_rental uuid, p_station uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'Nicht angemeldet'; end if;
  update rentals set returned_at = now() where id = p_rental and user_id = auth.uid() and returned_at is null;
  if not found then raise exception 'Keine aktive Ausleihe gefunden'; end if;
  update stations set available = least(available + 1, capacity) where id = p_station;
end; $$;

revoke all on function public.borrow_powerbank(uuid) from public, anon;
revoke all on function public.return_powerbank(uuid, uuid) from public, anon;
grant execute on function public.borrow_powerbank(uuid) to authenticated;
grant execute on function public.return_powerbank(uuid, uuid) to authenticated;
